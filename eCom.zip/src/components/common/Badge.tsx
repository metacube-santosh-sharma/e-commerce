const Badge = (props:any) => {
    return (<div className="badge"><strong>{props.count}</strong></div>);
}
export default Badge;