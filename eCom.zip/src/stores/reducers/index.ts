import { combineReducers } from "@reduxjs/toolkit";
import cartSlice from '../reducers/cart';

const reducers = combineReducers({cartSlice});
export default reducers;