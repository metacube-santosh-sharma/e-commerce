import { createSlice } from "@reduxjs/toolkit"

const initialState = {
    count: 0
}

const cartSlice = createSlice({name: 'cartSlice', initialState, reducers: {
    handleCount: (state, action) => {
        console.log("Hey cart slice")
    }
}});
export default cartSlice.reducer;
export const { handleCount } = cartSlice.actions;