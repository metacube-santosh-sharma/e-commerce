import React, { useContext, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import Home from './components/Home';
import Contact from './components/Contact';
import Faq from './components/Faq';
import About from './components/About';
import { ToastContainer } from 'react-toastify';
import { useSelector } from 'react-redux';
import { handleCount } from './stores/reducers/cart';
import {dispatch} from 'store'
function App() {
  const { count } = useSelector((state: any) => state.cartSlice)
  useEffect(() => {
    console.log('.........', count)
  }, [count])
  const handleClick = () => {
    dispatch(handleCount())
  }
  return (
    <>
    <div onClick={handleClick}>Hiii click</div>
    <ToastContainer hideProgressBar={true}  closeOnClick pauseOnHover/>
      <Router>
        <Routes>
          <Route path='/' element={< Login />}></Route>
          <Route path='/home' element={< Home />}></Route>
          <Route path='/about' element={< About />}></Route>
          <Route path='/faq' element={< Faq />}></Route>
          <Route path='/contact' element={< Contact />}></Route>
        </Routes>
      </Router>
    </>
  );
}

export default App;
